
# Reporting

Report to Microsoft Teams, the number of product, on a daily basis.

(over webhooks)

## Webhooks

Doc: https://docs.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook

```
export DB_URI=foo:bar@tcp(127.0.0.1:3306)/mydb

export WEBHOOK_URL=https://outlook.office.com/webhook/xxxxxxxxxxxxxxx
```